FUNCTION z_stud_get.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IV_MATRICULE) TYPE  ZSTUD_STUDENT-MATRICULE
*"  EXPORTING
*"     REFERENCE(ES_STUDENT) TYPE  ZSTUD_STUDENT
*"  EXCEPTIONS
*"      NOT_FOUND
*"----------------------------------------------------------------------

  CLEAR es_student.

  SELECT SINGLE *
    FROM zstud_student
    INTO es_student
    WHERE matricule = iv_matricule.

  IF sy-subrc <> 0.
    RAISE not_found.
  ENDIF.

ENDFUNCTION.
