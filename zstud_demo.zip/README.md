# ZSTUD abapGit demo

Petit dépôt de test abapGit : une table + un groupe de fonctions avec un FM.

## Objets
- `ZSTUD_STUDENT` (table transparente) : base étudiants de démo
- `ZSTUD_FG` (groupe de fonctions) contenant :
  - `Z_STUD_GET` (FM) : lit un étudiant par son matricule

## Import (ABAP Platform 2023)
1. Transaction `ZABAPGIT` (ou abapGit dans ADT / Eclipse).
2. New Offline → nom du repo : ZSTUD, package cible : un package Z/$ existant
   (ex. `$ZSTUD` pour du local, ou un package transportable).
3. Import ZIP → sélectionner `zstud_demo.zip`.
4. Pull / Import → cocher les 2 objets → confirmer.
5. abapGit active automatiquement ; vérifier la pastille verte.

## Ordre d'activation
La table s'active avant le FM (le FM référence la table). abapGit gère
l'ordre tout seul ; en cas de warning sur le FM au premier pull, relancer
le Pull une 2e fois une fois la table active.
